<?php
    session_start();
    include("connection.php");
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        $question = $_POST['question'];
        $subject = $_POST['subject'];
        $a = $_POST['a'];
        $b = $_POST['b'];
        $c = $_POST['c'];
        $d = $_POST['d'];
        $correct = $_POST['correct'];
        if(!empty($question) && !empty($subject) && !empty($a) && !empty($b) && !empty($c) && !empty($d) &&!empty($correct)){
            $query1 = "insert into questions(Question,Subject) values ('$question','$subject')";
            $query2 = "insert into options(Subject,a,b,c,d,correct) values ('$subject','$a','$b','$c','$d','$correct')";
            mysqli_query($con,$query1);
            mysqli_query($con,$query2);   
        }
        else{
            echo "DO NOT LEAVE ANY FIELD EMPTY";
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <h1>Enter Questions to be added to the database</h1>
        Subject : <input type="text" name="subject"><br>
        Question : <input type="text" name="question" id=""><br>
        Option A : <input type="text" name="a"><br>
        Option B : <input type="text" name="b"><br>
        Option C : <input type="text" name="c"><br>
        Option D : <input type="text" name="d"><br>
        Correct Option : <input type="text" name="correct"><br>
        
        <input type="submit" value="ADD TO DATABASE"><br>
        <a href="exit.php">Exit</a>
    </form>
</body>
</html>