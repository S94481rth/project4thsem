<?php
    session_start();
    include("functions.php");
    include("connection.php");
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
      $USN = $_POST['USN'];
      $password = $_POST['password'];
      
      if(!empty($USN) && !empty($password)){
          
            $query = "select * from student_info where USN = '$USN' limit 1";
            $result = mysqli_query($con,$query);
            if($result && mysqli_num_rows($result) > 0){
              $user_data = mysqli_fetch_assoc($result);
              if($user_data['password'] === $password){
                $_SESSION['USN'] = $user_data['USN'];
                header("Location: homePage.php");
                die; 
              }
            }
            echo "Wrong Credentials";
      }
      else{
        echo "Please do not leave any field empty! ";
      }
  }
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <h1>Login Page</h1>

        USN : <input type="text" name="USN" id=""><br>
        Password : <input type="password" name="password"><br>
        <input type="submit" value="Login"><br>
        <a href="signin.php">Create Accout? Signin</a>
    </form>

</body>
</html>