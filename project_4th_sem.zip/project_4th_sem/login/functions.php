<?php
    function checkLogin($con){
        
        if(isset($_SESSION['USN'])){
            $id = $_SESSION['USN'];
            $sql = "select * from student_info where USN = '$id' limit 1" ;
            $result = mysqli_query($con,$sql);
            if($result && mysqli_num_rows($result) > 0){
                $user_data = mysqli_fetch_assoc($result);
                return $user_data;
            }
        }
        //return to login.php
       header("Location: login.php");
        die;
    }

